import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMail, FiPhone, FiPlus, FiTrash2, FiEdit3, FiCamera, FiX, FiSave, FiEye, FiMaximize2 } from 'react-icons/fi';
import { useAuthStore } from '../store/authStore';
import { useContentStore } from '../store/contentStore';
import RichTextEditor from '../components/RichTextEditor';
import FileUploader from '../components/FileUploader';

export default function EditorSection() {
  const { isAuthenticated } = useAuthStore();
  const {
    editorTitle,
    projects,
    editorImage,
    updateEditorTitle,
    addProject,
    deleteProject,
    updateEditorImage,
  } = useContentStore();

  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editTitleValue, setEditTitleValue] = useState(editorTitle);
  const [showAddProject, setShowAddProject] = useState(false);
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);
  const [newProject, setNewProject] = useState({ 
    title: '', 
    content: '', 
    category: 'Photo Editing',
    beforeImage: '',
    afterImage: ''
  });
  const [sliderPosition, setSliderPosition] = useState(50);

  const handleSaveTitle = () => {
    updateEditorTitle(editTitleValue);
    setIsEditingTitle(false);
  };

  const handleAddProject = () => {
    if (newProject.title) {
      addProject({
        id: Date.now().toString(),
        title: newProject.title,
        content: newProject.content,
        category: newProject.category,
        fileUrl: newProject.afterImage || newProject.beforeImage,
        fileName: newProject.beforeImage,
        createdAt: new Date().toISOString(),
      });
      setNewProject({ title: '', content: '', category: 'Photo Editing', beforeImage: '', afterImage: '' });
      setShowAddProject(false);
    }
  };

  return (
    <section id="editor" className="relative min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-black overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-20">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(rgba(99, 102, 241, 0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(99, 102, 241, 0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.1, 0.15, 0.1],
        }}
        transition={{ duration: 10, repeat: Infinity, delay: 2 }}
        className="absolute bottom-0 left-0 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl"
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          {isAuthenticated && isEditingTitle ? (
            <div className="max-w-xl mx-auto space-y-4">
              <input
                type="text"
                value={editTitleValue}
                onChange={(e) => setEditTitleValue(e.target.value)}
                className="w-full px-4 py-3 bg-gray-900 border border-indigo-800 rounded-lg text-white text-center text-3xl font-bold focus:outline-none focus:border-indigo-500"
              />
              <div className="flex justify-center space-x-4">
                <button onClick={handleSaveTitle} className="px-6 py-2 bg-indigo-600 text-white rounded-lg flex items-center space-x-2">
                  <FiSave size={16} /> <span>Save</span>
                </button>
                <button onClick={() => setIsEditingTitle(false)} className="px-6 py-2 bg-gray-800 text-white rounded-lg">
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="relative inline-block">
              <motion.h2
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="text-4xl sm:text-5xl lg:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 font-['Inter']"
              >
                {editorTitle}
              </motion.h2>
              {isAuthenticated && (
                <button
                  onClick={() => setIsEditingTitle(true)}
                  className="absolute -right-10 top-1/2 -translate-y-1/2 p-2 bg-indigo-900/50 rounded-full text-indigo-400 hover:bg-indigo-900"
                >
                  <FiEdit3 size={16} />
                </button>
              )}
            </div>
          )}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="mt-6 text-gray-400 text-lg max-w-2xl mx-auto"
          >
            Professional photo editing & visual design services
          </motion.p>
        </motion.div>

        {/* Section Image */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="aspect-[21/9] rounded-2xl overflow-hidden border border-gray-800 max-w-4xl mx-auto">
            {editorImage ? (
              <img src={editorImage} alt="Photo Editor" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                <FiCamera size={64} className="text-gray-800" />
              </div>
            )}
          </div>
          {isAuthenticated && (
            <div className="max-w-md mx-auto mt-4">
              <FileUploader
                accept="image/*"
                label="Section Banner Image"
                darkMode={true}
                onFileSelect={(file) => updateEditorImage(file.url)}
              />
            </div>
          )}
        </motion.div>

        {/* Add Project Button */}
        {isAuthenticated && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowAddProject(true)}
            className="w-full max-w-md mx-auto mb-12 py-4 border-2 border-dashed border-indigo-800/50 rounded-xl text-indigo-400 hover:border-indigo-700 hover:bg-indigo-900/20 transition-all flex items-center justify-center space-x-2"
          >
            <FiPlus size={20} />
            <span>Add New Project</span>
          </motion.button>
        )}

        {/* Projects Gallery */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.length === 0 ? (
            <div className="col-span-full text-center py-20">
              <FiCamera size={48} className="text-gray-700 mx-auto mb-4" />
              <p className="text-gray-600">No projects yet. Add your first project!</p>
            </div>
          ) : (
            projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative"
              >
                <motion.div
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-gray-800 bg-gray-900 cursor-pointer"
                  onClick={() => setSelectedProject(project)}
                >
                  {project.fileUrl ? (
                    <img 
                      src={project.fileUrl} 
                      alt={project.title} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-900/50 to-purple-900/50">
                      <FiCamera size={32} className="text-gray-600" />
                    </div>
                  )}
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                    <span className="text-xs text-indigo-400 uppercase tracking-wider mb-2">
                      {project.category}
                    </span>
                    <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                    <div className="flex items-center space-x-3">
                      <span className="flex items-center space-x-1 text-gray-400 text-sm">
                        <FiEye size={14} />
                        <span>View</span>
                      </span>
                      <span className="flex items-center space-x-1 text-gray-400 text-sm">
                        <FiMaximize2 size={14} />
                        <span>Expand</span>
                      </span>
                    </div>
                  </div>

                  {/* Delete Button */}
                  {isAuthenticated && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteProject(project.id);
                      }}
                      className="absolute top-3 right-3 p-2 bg-black/70 rounded-full text-gray-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all z-10"
                    >
                      <FiTrash2 size={16} />
                    </button>
                  )}
                </motion.div>
              </motion.div>
            ))
          )}
        </div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <h3 className="text-2xl font-bold text-white mb-6">Hire Me</h3>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <motion.a
              href="mailto:sheikhmahadirahmansami@gmail.com"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center space-x-3 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full font-semibold hover:from-indigo-500 hover:to-purple-500 transition-all shadow-lg shadow-indigo-500/25"
            >
              <FiMail size={20} />
              <span>Get In Touch</span>
            </motion.a>
            <motion.a
              href="tel:01410430830"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center space-x-3 px-8 py-4 bg-gray-800 text-white rounded-full font-semibold hover:bg-gray-700 transition-all border border-gray-700"
            >
              <FiPhone size={20} />
              <span>01410430830</span>
            </motion.a>
          </div>
        </motion.div>
      </div>

      {/* Project Detail Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-sm"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-4xl bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Project Image */}
              <div className="aspect-video bg-black">
                {selectedProject.fileName && selectedProject.fileUrl ? (
                  // Before/After Slider
                  <div className="relative w-full h-full">
                    <img 
                      src={selectedProject.fileUrl} 
                      alt="After" 
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <div 
                      className="absolute inset-0 overflow-hidden"
                      style={{ width: `${sliderPosition}%` }}
                    >
                      <img 
                        src={selectedProject.fileName} 
                        alt="Before" 
                        className="w-full h-full object-cover"
                        style={{ width: `${100 / (sliderPosition / 100)}%`, maxWidth: 'none' }}
                      />
                    </div>
                    {/* Slider */}
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={sliderPosition}
                      onChange={(e) => setSliderPosition(Number(e.target.value))}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
                    />
                    <div 
                      className="absolute top-0 bottom-0 w-1 bg-white shadow-lg"
                      style={{ left: `${sliderPosition}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-lg">
                        <div className="flex space-x-0.5">
                          <div className="w-0.5 h-3 bg-gray-400" />
                          <div className="w-0.5 h-3 bg-gray-400" />
                        </div>
                      </div>
                    </div>
                    <div className="absolute top-4 left-4 px-3 py-1 bg-black/70 rounded text-white text-sm">Before</div>
                    <div className="absolute top-4 right-4 px-3 py-1 bg-black/70 rounded text-white text-sm">After</div>
                  </div>
                ) : selectedProject.fileUrl ? (
                  <img 
                    src={selectedProject.fileUrl} 
                    alt={selectedProject.title} 
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <FiCamera size={64} className="text-gray-700" />
                  </div>
                )}
              </div>

              {/* Project Info */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-xs text-indigo-400 uppercase tracking-wider">
                      {selectedProject.category}
                    </span>
                    <h2 className="text-2xl font-bold text-white mt-1">{selectedProject.title}</h2>
                  </div>
                  <button
                    onClick={() => setSelectedProject(null)}
                    className="p-3 bg-gray-800 rounded-full text-gray-400 hover:text-white"
                  >
                    <FiX size={24} />
                  </button>
                </div>
                {selectedProject.content && (
                  <div 
                    className="text-gray-400 prose prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: selectedProject.content }}
                  />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Project Modal */}
      <AnimatePresence>
        {showAddProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm overflow-y-auto"
            onClick={() => setShowAddProject(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-2xl bg-gray-900 border border-gray-800 rounded-2xl p-6 my-8 max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Add New Project</h3>
                <button onClick={() => setShowAddProject(false)} className="p-2 text-gray-400 hover:text-white">
                  <FiX size={24} />
                </button>
              </div>
              
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Project Title"
                  value={newProject.title}
                  onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
                <select
                  value={newProject.category}
                  onChange={(e) => setNewProject({ ...newProject, category: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="Photo Editing">Photo Editing</option>
                  <option value="Color Grading">Color Grading</option>
                  <option value="Retouching">Retouching</option>
                  <option value="Compositing">Compositing</option>
                  <option value="Other">Other</option>
                </select>
                <RichTextEditor
                  value={newProject.content}
                  onChange={(value) => setNewProject({ ...newProject, content: value })}
                  placeholder="Project description..."
                  darkMode={true}
                />
                <FileUploader
                  accept="image/*"
                  label="Before Image (Optional for slider)"
                  darkMode={true}
                  onFileSelect={(file) => setNewProject({ ...newProject, beforeImage: file.url })}
                />
                <FileUploader
                  accept="image/*"
                  label="After Image / Main Image"
                  darkMode={true}
                  onFileSelect={(file) => setNewProject({ ...newProject, afterImage: file.url })}
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAddProject}
                  className="w-full py-4 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-500"
                >
                  Add Project
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
