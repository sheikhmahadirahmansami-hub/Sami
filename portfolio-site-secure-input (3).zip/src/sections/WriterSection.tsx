import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMail, FiHeart, FiPlus, FiTrash2, FiEdit3, FiCamera, FiX, FiSave, FiBook, FiFeather } from 'react-icons/fi';
import { useAuthStore } from '../store/authStore';
import { useContentStore } from '../store/contentStore';
import RichTextEditor from '../components/RichTextEditor';
import FileUploader from '../components/FileUploader';

export default function WriterSection() {
  const { isAuthenticated } = useAuthStore();
  const {
    writerTitle,
    writings,
    writerImage,
    updateWriterTitle,
    addWriting,
    deleteWriting,
    updateWriterImage,
    addEmotion,
  } = useContentStore();

  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editTitleValue, setEditTitleValue] = useState(writerTitle);
  const [showAddWriting, setShowAddWriting] = useState(false);
  const [selectedWriting, setSelectedWriting] = useState<typeof writings[0] | null>(null);
  const [newWriting, setNewWriting] = useState({ title: '', content: '', category: 'Poetry' });
  const [emotionForm, setEmotionForm] = useState({ name: '', emotion: '' });
  const [emotionSubmitted, setEmotionSubmitted] = useState(false);

  const handleSaveTitle = () => {
    updateWriterTitle(editTitleValue);
    setIsEditingTitle(false);
  };

  const handleAddWriting = () => {
    if (newWriting.title && newWriting.content) {
      addWriting({
        id: Date.now().toString(),
        title: newWriting.title,
        content: newWriting.content,
        category: newWriting.category,
        createdAt: new Date().toISOString(),
      });
      setNewWriting({ title: '', content: '', category: 'Poetry' });
      setShowAddWriting(false);
    }
  };

  const handleEmotionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (emotionForm.emotion) {
      addEmotion({
        id: Date.now().toString(),
        title: emotionForm.name || 'Anonymous',
        content: emotionForm.emotion,
        createdAt: new Date().toISOString(),
      });
      setEmotionForm({ name: '', emotion: '' });
      setEmotionSubmitted(true);
      setTimeout(() => setEmotionSubmitted(false), 3000);
    }
  };

  return (
    <section id="writer" className="relative min-h-screen overflow-hidden" style={{ background: 'linear-gradient(135deg, #2c1810 0%, #1a0f0a 50%, #0d0705 100%)' }}>
      {/* Manuscript Paper Texture Background */}
      <div className="absolute inset-0">
        {/* Paper Texture */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23d4a574' fill-opacity='0.4'%3E%3Cpath d='M0 0h100v100H0z'/%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: '100px 100px',
          }}
        />
        
        {/* Vignette Effect */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.7)_100%)]" />
        
        {/* Warm Golden Glow */}
        <motion.div
          animate={{
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-gradient-radial from-amber-900/20 to-transparent blur-3xl rounded-full"
        />
        
        {/* Floating Dust Particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000),
              y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 800),
              opacity: 0 
            }}
            animate={{ 
              y: [null, -100],
              opacity: [0, 0.5, 0],
            }}
            transition={{ 
              duration: 10 + Math.random() * 10,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
            className="absolute w-1 h-1 bg-amber-200/30 rounded-full"
          />
        ))}
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center mb-20"
        >
          {isAuthenticated && isEditingTitle ? (
            <div className="max-w-xl mx-auto space-y-4">
              <input
                type="text"
                value={editTitleValue}
                onChange={(e) => setEditTitleValue(e.target.value)}
                className="w-full px-4 py-3 bg-amber-900/30 border border-amber-800 rounded-lg text-amber-100 text-center text-3xl font-['Noto_Serif_Bengali'] focus:outline-none focus:border-amber-500"
              />
              <div className="flex justify-center space-x-4">
                <button onClick={handleSaveTitle} className="px-6 py-2 bg-amber-700 text-white rounded-lg flex items-center space-x-2">
                  <FiSave size={16} /> <span>Save</span>
                </button>
                <button onClick={() => setIsEditingTitle(false)} className="px-6 py-2 bg-amber-900/50 text-amber-100 rounded-lg">
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="relative inline-block">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="relative"
              >
                {/* Decorative Elements */}
                <motion.div
                  animate={{ rotate: [0, 5, -5, 0] }}
                  transition={{ duration: 8, repeat: Infinity }}
                  className="absolute -left-16 top-1/2 -translate-y-1/2 text-amber-700/30"
                >
                  <FiFeather size={48} />
                </motion.div>
                <motion.div
                  animate={{ rotate: [0, -5, 5, 0] }}
                  transition={{ duration: 8, repeat: Infinity, delay: 1 }}
                  className="absolute -right-16 top-1/2 -translate-y-1/2 text-amber-700/30"
                >
                  <FiBook size={48} />
                </motion.div>
                
                <h2
                  className="text-5xl sm:text-6xl lg:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-amber-300 to-amber-600 font-['Noto_Serif_Bengali']"
                  style={{ textShadow: '0 0 80px rgba(217, 119, 6, 0.3)' }}
                >
                  {writerTitle}
                </h2>
              </motion.div>
              {isAuthenticated && (
                <button
                  onClick={() => setIsEditingTitle(true)}
                  className="absolute -right-10 top-1/2 -translate-y-1/2 p-2 bg-amber-900/50 rounded-full text-amber-400 hover:bg-amber-900"
                >
                  <FiEdit3 size={16} />
                </button>
              )}
            </div>
          )}
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="mt-6 text-amber-200/60 text-lg italic font-['Noto_Serif_Bengali']"
          >
            মধ্যরাতের লেখকের কক্ষ • কবিতার অভয়ারণ্য
          </motion.p>
          
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.3 }}
            className="h-px w-48 bg-gradient-to-r from-transparent via-amber-600 to-transparent mx-auto mt-8"
          />
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Left - Writer Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2"
          >
            <div className="sticky top-32 space-y-6">
              <div className="aspect-[3/4] rounded-2xl overflow-hidden border-2 border-amber-900/50 shadow-2xl shadow-black/50">
                {writerImage ? (
                  <img src={writerImage} alt="The Writer" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-amber-900/30 to-black flex items-center justify-center">
                    <FiCamera size={48} className="text-amber-800/50" />
                  </div>
                )}
              </div>
              {isAuthenticated && (
                <FileUploader
                  accept="image/*"
                  label="Section Image"
                  darkMode={true}
                  onFileSelect={(file) => updateWriterImage(file.url)}
                />
              )}
              
              {/* Contact Button */}
              <motion.a
                href="mailto:sheikhmahadirahmansami@gmail.com"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center justify-center space-x-3 px-6 py-4 bg-gradient-to-r from-amber-900/50 to-amber-800/30 border border-amber-800/50 text-amber-200 rounded-xl hover:border-amber-700 transition-all"
              >
                <FiMail size={20} />
                <span className="font-['Noto_Serif_Bengali']">যোগাযোগ করুন</span>
              </motion.a>
            </div>
          </motion.div>

          {/* Right - Writings */}
          <div className="lg:col-span-3 space-y-8">
            {/* Add Writing Button */}
            {isAuthenticated && (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowAddWriting(true)}
                className="w-full py-4 border-2 border-dashed border-amber-800/50 rounded-xl text-amber-400 hover:border-amber-700 hover:bg-amber-900/20 transition-all flex items-center justify-center space-x-2"
              >
                <FiPlus size={20} />
                <span>Add New Writing</span>
              </motion.button>
            )}

            {/* Writings List */}
            <div className="space-y-6">
              {writings.map((writing, index) => (
                <motion.div
                  key={writing.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="group"
                >
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    onClick={() => setSelectedWriting(writing)}
                    className="cursor-pointer p-6 bg-gradient-to-br from-amber-950/50 to-black/50 border border-amber-900/30 rounded-2xl hover:border-amber-800/50 transition-all shadow-xl"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <span className="text-xs px-3 py-1 bg-amber-900/50 text-amber-400 rounded-full">
                          {writing.category || 'Poetry'}
                        </span>
                        <span className="ml-3 text-xs text-amber-700">
                          {new Date(writing.createdAt).toLocaleDateString('bn-BD')}
                        </span>
                      </div>
                      {isAuthenticated && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteWriting(writing.id);
                          }}
                          className="p-2 text-amber-800 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                        >
                          <FiTrash2 size={16} />
                        </button>
                      )}
                    </div>
                    <h3 className="text-2xl font-bold text-amber-100 mb-4 font-['Noto_Serif_Bengali']">
                      {writing.title}
                    </h3>
                    <div 
                      className="text-amber-200/70 leading-relaxed line-clamp-4 font-['Noto_Serif_Bengali'] prose prose-amber prose-invert max-w-none"
                      dangerouslySetInnerHTML={{ __html: writing.content }}
                    />
                    <p className="mt-4 text-amber-500 text-sm flex items-center space-x-2">
                      <FiBook size={14} />
                      <span>Click to read more...</span>
                    </p>
                  </motion.div>
                </motion.div>
              ))}
            </div>

            {/* Emotion Feedback Form */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mt-12 p-6 bg-gradient-to-br from-amber-950/30 to-black/30 border border-amber-900/30 rounded-2xl"
            >
              <div className="flex items-center space-x-3 mb-6">
                <FiHeart className="text-amber-500" size={24} />
                <h3 className="text-xl font-bold text-amber-200 font-['Noto_Serif_Bengali']">আপনার অনুভূতি</h3>
              </div>
              
              <AnimatePresence mode="wait">
                {emotionSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-8"
                  >
                    <div className="w-16 h-16 bg-amber-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <FiHeart size={24} className="text-amber-400" />
                    </div>
                    <p className="text-amber-200 font-semibold font-['Noto_Serif_Bengali']">ধন্যবাদ!</p>
                    <p className="text-amber-600 text-sm mt-2">আপনার অনুভূতি শেয়ার করার জন্য।</p>
                  </motion.div>
                ) : (
                  <motion.form
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    onSubmit={handleEmotionSubmit}
                    className="space-y-4"
                  >
                    <input
                      type="text"
                      placeholder="আপনার নাম (ঐচ্ছিক)"
                      value={emotionForm.name}
                      onChange={(e) => setEmotionForm({ ...emotionForm, name: e.target.value })}
                      className="w-full px-4 py-3 bg-amber-950/30 border border-amber-900/50 rounded-xl text-amber-100 placeholder-amber-700 focus:outline-none focus:border-amber-700 font-['Noto_Serif_Bengali']"
                    />
                    <textarea
                      placeholder="কবিতা পড়ে আপনার মনে কি অনুভূতি জাগলো?"
                      value={emotionForm.emotion}
                      onChange={(e) => setEmotionForm({ ...emotionForm, emotion: e.target.value })}
                      rows={4}
                      required
                      className="w-full px-4 py-3 bg-amber-950/30 border border-amber-900/50 rounded-xl text-amber-100 placeholder-amber-700 focus:outline-none focus:border-amber-700 resize-none font-['Noto_Serif_Bengali']"
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      type="submit"
                      className="w-full py-4 bg-gradient-to-r from-amber-800 to-amber-700 text-white rounded-xl font-semibold flex items-center justify-center space-x-2 hover:from-amber-700 hover:to-amber-600"
                    >
                      <FiHeart size={18} />
                      <span className="font-['Noto_Serif_Bengali']">শেয়ার করুন</span>
                    </motion.button>
                  </motion.form>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Reading Mode Modal */}
      <AnimatePresence>
        {selectedWriting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md overflow-y-auto"
            onClick={() => setSelectedWriting(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 50 }}
              className="w-full max-w-3xl bg-gradient-to-br from-amber-950/80 to-black border border-amber-900/50 rounded-3xl p-8 md:p-12 my-8 max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-end mb-6">
                <button
                  onClick={() => setSelectedWriting(null)}
                  className="p-3 bg-amber-900/50 rounded-full text-amber-400 hover:bg-amber-800"
                >
                  <FiX size={24} />
                </button>
              </div>
              
              <div className="text-center mb-8">
                <span className="text-sm px-4 py-1 bg-amber-900/50 text-amber-400 rounded-full">
                  {selectedWriting.category || 'Poetry'}
                </span>
                <h2 className="text-3xl md:text-4xl font-bold text-amber-100 mt-6 font-['Noto_Serif_Bengali']">
                  {selectedWriting.title}
                </h2>
                <p className="text-amber-600 mt-2 text-sm">
                  {new Date(selectedWriting.createdAt).toLocaleDateString('bn-BD', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
              
              <div className="w-16 h-px bg-amber-700 mx-auto mb-8" />
              
              <div 
                className="text-amber-200/90 text-lg md:text-xl leading-loose font-['Noto_Serif_Bengali'] prose prose-amber prose-invert max-w-none whitespace-pre-wrap"
                style={{ textAlign: 'center' }}
                dangerouslySetInnerHTML={{ __html: selectedWriting.content }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Writing Modal */}
      <AnimatePresence>
        {showAddWriting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
            onClick={() => setShowAddWriting(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-2xl bg-gradient-to-br from-amber-950 to-black border border-amber-900 rounded-2xl p-6 max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-amber-100 font-['Noto_Serif_Bengali']">নতুন লেখা যোগ করুন</h3>
                <button onClick={() => setShowAddWriting(false)} className="p-2 text-amber-400 hover:text-amber-200">
                  <FiX size={24} />
                </button>
              </div>
              
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="শিরোনাম"
                  value={newWriting.title}
                  onChange={(e) => setNewWriting({ ...newWriting, title: e.target.value })}
                  className="w-full px-4 py-3 bg-amber-950/50 border border-amber-900 rounded-xl text-amber-100 focus:outline-none focus:border-amber-700 font-['Noto_Serif_Bengali']"
                />
                <select
                  value={newWriting.category}
                  onChange={(e) => setNewWriting({ ...newWriting, category: e.target.value })}
                  className="w-full px-4 py-3 bg-amber-950/50 border border-amber-900 rounded-xl text-amber-100 focus:outline-none focus:border-amber-700"
                >
                  <option value="Poetry">Poetry</option>
                  <option value="Story">Story</option>
                  <option value="Essay">Essay</option>
                  <option value="Other">Other</option>
                </select>
                <RichTextEditor
                  value={newWriting.content}
                  onChange={(value) => setNewWriting({ ...newWriting, content: value })}
                  placeholder="আপনার লেখা এখানে লিখুন..."
                  darkMode={true}
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAddWriting}
                  className="w-full py-4 bg-amber-700 text-white rounded-xl font-semibold hover:bg-amber-600 font-['Noto_Serif_Bengali']"
                >
                  প্রকাশ করুন
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
