import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMail, FiSend, FiPlus, FiTrash2, FiEdit3, FiDownload, FiCamera, FiX, FiSave } from 'react-icons/fi';
import { useAuthStore } from '../store/authStore';
import { useContentStore } from '../store/contentStore';
import RichTextEditor from '../components/RichTextEditor';
import FileUploader from '../components/FileUploader';

export default function RebelSection() {
  const { isAuthenticated } = useAuthStore();
  const {
    rebelTitle,
    rebelVision,
    rebelResearch,
    rebelImage,
    updateRebelTitle,
    updateRebelVision,
    addResearch,
    deleteResearch,
    updateRebelImage,
    addQuestion,
  } = useContentStore();

  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [isEditingVision, setIsEditingVision] = useState(false);
  const [editTitleValue, setEditTitleValue] = useState(rebelTitle);
  const [editVisionValue, setEditVisionValue] = useState(rebelVision);
  const [showAddResearch, setShowAddResearch] = useState(false);
  const [newResearch, setNewResearch] = useState({ title: '', content: '', category: '', file: { name: '', url: '' } });
  const [questionForm, setQuestionForm] = useState({ name: '', email: '', question: '' });
  const [questionSubmitted, setQuestionSubmitted] = useState(false);

  const handleSaveTitle = () => {
    updateRebelTitle(editTitleValue);
    setIsEditingTitle(false);
  };

  const handleSaveVision = () => {
    updateRebelVision(editVisionValue);
    setIsEditingVision(false);
  };

  const handleAddResearch = () => {
    if (newResearch.title) {
      addResearch({
        id: Date.now().toString(),
        title: newResearch.title,
        content: newResearch.content,
        category: newResearch.category,
        fileName: newResearch.file.name,
        fileUrl: newResearch.file.url,
        createdAt: new Date().toISOString(),
      });
      setNewResearch({ title: '', content: '', category: '', file: { name: '', url: '' } });
      setShowAddResearch(false);
    }
  };

  const handleQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (questionForm.question) {
      addQuestion({
        id: Date.now().toString(),
        title: questionForm.name || 'Anonymous',
        content: questionForm.question,
        category: questionForm.email,
        createdAt: new Date().toISOString(),
      });
      setQuestionForm({ name: '', email: '', question: '' });
      setQuestionSubmitted(true);
      setTimeout(() => setQuestionSubmitted(false), 3000);
    }
  };

  return (
    <section id="rebel" className="relative min-h-screen bg-black overflow-hidden">
      {/* Cinematic Background */}
      <div className="absolute inset-0">
        {/* Smoke/Grain Overlay */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJhIiB4PSIwIiB5PSIwIj48ZmVUdXJidWxlbmNlIGJhc2VGcmVxdWVuY3k9Ii43NSIgc3RpdGNoVGlsZXM9InN0aXRjaCIgdHlwZT0iZnJhY3RhbE5vaXNlIi8+PGZlQ29sb3JNYXRyaXggdHlwZT0ic2F0dXJhdGUiIHZhbHVlcz0iMCIvPjwvZmlsdGVyPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbHRlcj0idXJsKCNhKSIgb3BhY2l0eT0iMC4wNSIvPjwvc3ZnPg==')] opacity-50" />
        
        {/* Red Accent Gradient */}
        <motion.div
          animate={{
            opacity: [0.1, 0.2, 0.1],
            scale: [1, 1.1, 1],
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-bl from-red-900/30 to-transparent blur-3xl"
        />
        <motion.div
          animate={{
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{ duration: 6, repeat: Infinity, delay: 2 }}
          className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-gradient-to-tr from-red-800/20 to-transparent blur-3xl"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          {isAuthenticated && isEditingTitle ? (
            <div className="max-w-2xl mx-auto space-y-4">
              <input
                type="text"
                value={editTitleValue}
                onChange={(e) => setEditTitleValue(e.target.value)}
                className="w-full px-4 py-3 bg-gray-900 border border-red-800 rounded-lg text-white text-center text-2xl font-bold focus:outline-none focus:border-red-500"
              />
              <div className="flex justify-center space-x-4">
                <button onClick={handleSaveTitle} className="px-6 py-2 bg-red-600 text-white rounded-lg flex items-center space-x-2">
                  <FiSave size={16} /> <span>Save</span>
                </button>
                <button onClick={() => setIsEditingTitle(false)} className="px-6 py-2 bg-gray-800 text-white rounded-lg">
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="relative inline-block">
              <motion.h2
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="text-4xl sm:text-5xl lg:text-7xl font-black text-white uppercase tracking-wider font-['Inter']"
                style={{ textShadow: '0 0 60px rgba(220, 38, 38, 0.5)' }}
              >
                {rebelTitle}
              </motion.h2>
              {isAuthenticated && (
                <button
                  onClick={() => setIsEditingTitle(true)}
                  className="absolute -right-10 top-1/2 -translate-y-1/2 p-2 bg-red-900/50 rounded-full text-red-400 hover:bg-red-900"
                >
                  <FiEdit3 size={16} />
                </button>
              )}
            </div>
          )}
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: '200px' }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.5 }}
            className="h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto mt-8"
          />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left Column */}
          <div className="space-y-12">
            {/* Vision */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <h3 className="text-red-500 uppercase tracking-widest text-sm font-bold mb-4">My Vision</h3>
              {isAuthenticated && isEditingVision ? (
                <div className="space-y-4">
                  <RichTextEditor
                    value={editVisionValue}
                    onChange={setEditVisionValue}
                    placeholder="Write your vision..."
                    darkMode={true}
                  />
                  <div className="flex space-x-4">
                    <button onClick={handleSaveVision} className="px-6 py-2 bg-red-600 text-white rounded-lg flex items-center space-x-2">
                      <FiSave size={16} /> <span>Save</span>
                    </button>
                    <button onClick={() => setIsEditingVision(false)} className="px-6 py-2 bg-gray-800 text-white rounded-lg">
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="relative group">
                  <div
                    className="text-gray-300 text-lg leading-relaxed prose prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: rebelVision }}
                  />
                  {isAuthenticated && (
                    <button
                      onClick={() => { setEditVisionValue(rebelVision); setIsEditingVision(true); }}
                      className="absolute -right-4 top-0 p-2 bg-red-900/50 rounded-full text-red-400 hover:bg-red-900 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <FiEdit3 size={16} />
                    </button>
                  )}
                </div>
              )}
            </motion.div>

            {/* Research Archive */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-red-500 uppercase tracking-widest text-sm font-bold">My Research</h3>
                {isAuthenticated && (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setShowAddResearch(true)}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-900/50 text-red-400 rounded-lg hover:bg-red-900 transition-colors"
                  >
                    <FiPlus size={16} />
                    <span>Add Research</span>
                  </motion.button>
                )}
              </div>

              <div className="space-y-4">
                {rebelResearch.length === 0 ? (
                  <p className="text-gray-600 italic">No research entries yet.</p>
                ) : (
                  rebelResearch.map((research, index) => (
                    <motion.div
                      key={research.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 bg-gray-900/50 border border-gray-800 rounded-xl hover:border-red-900 transition-colors group"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <span className="text-xs px-2 py-1 bg-red-900/50 text-red-400 rounded">
                              {research.category || 'Research'}
                            </span>
                            <span className="text-xs text-gray-600">
                              {new Date(research.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <h4 className="text-white font-semibold mb-2">{research.title}</h4>
                          <div className="text-gray-400 text-sm line-clamp-2" dangerouslySetInnerHTML={{ __html: research.content }} />
                          {research.fileUrl && (
                            <a
                              href={research.fileUrl}
                              download={research.fileName}
                              className="inline-flex items-center space-x-2 mt-3 text-red-400 hover:text-red-300 text-sm"
                            >
                              <FiDownload size={14} />
                              <span>{research.fileName || 'Download File'}</span>
                            </a>
                          )}
                        </div>
                        {isAuthenticated && (
                          <button
                            onClick={() => deleteResearch(research.id)}
                            className="p-2 text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                          >
                            <FiTrash2 size={16} />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          </div>

          {/* Right Column */}
          <div className="space-y-12">
            {/* Section Image */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="aspect-[4/3] rounded-2xl overflow-hidden border border-gray-800">
                {rebelImage ? (
                  <img src={rebelImage} alt="The Rebel" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                    <FiCamera size={48} className="text-gray-700" />
                  </div>
                )}
              </div>
              {isAuthenticated && (
                <div className="mt-4">
                  <FileUploader
                    accept="image/*"
                    label="Section Image"
                    darkMode={true}
                    onFileSelect={(file) => updateRebelImage(file.url)}
                  />
                </div>
              )}
            </motion.div>

            {/* Ask Question Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-2xl p-6"
            >
              <h3 className="text-red-500 uppercase tracking-widest text-sm font-bold mb-6">Ask Any Question</h3>
              
              <AnimatePresence mode="wait">
                {questionSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-8"
                  >
                    <div className="w-16 h-16 bg-green-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <FiSend size={24} className="text-green-400" />
                    </div>
                    <p className="text-white font-semibold">Question Submitted!</p>
                    <p className="text-gray-500 text-sm mt-2">Thank you for your inquiry.</p>
                  </motion.div>
                ) : (
                  <motion.form
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    onSubmit={handleQuestionSubmit}
                    className="space-y-4"
                  >
                    <input
                      type="text"
                      placeholder="Your Name (optional)"
                      value={questionForm.name}
                      onChange={(e) => setQuestionForm({ ...questionForm, name: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
                    />
                    <input
                      type="email"
                      placeholder="Your Email (optional)"
                      value={questionForm.email}
                      onChange={(e) => setQuestionForm({ ...questionForm, email: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
                    />
                    <textarea
                      placeholder="Your Question..."
                      value={questionForm.question}
                      onChange={(e) => setQuestionForm({ ...questionForm, question: e.target.value })}
                      rows={4}
                      required
                      className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-red-500 resize-none"
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      type="submit"
                      className="w-full py-4 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-xl font-semibold flex items-center justify-center space-x-2 hover:from-red-500 hover:to-red-600"
                    >
                      <FiSend size={18} />
                      <span>Submit Question</span>
                    </motion.button>
                  </motion.form>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Contact */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex items-center justify-center"
            >
              <motion.a
                href="mailto:raisevoiceraisemovement@gmail.com"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center space-x-3 px-8 py-4 bg-gray-900 border border-red-900 text-white rounded-full hover:bg-red-900/20 transition-colors"
              >
                <FiMail size={20} className="text-red-400" />
                <span>raisevoiceraisemovement@gmail.com</span>
              </motion.a>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Add Research Modal */}
      <AnimatePresence>
        {showAddResearch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
            onClick={() => setShowAddResearch(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-2xl bg-gray-900 border border-gray-800 rounded-2xl p-6 max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Add New Research</h3>
                <button onClick={() => setShowAddResearch(false)} className="p-2 text-gray-400 hover:text-white">
                  <FiX size={24} />
                </button>
              </div>
              
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Research Title"
                  value={newResearch.title}
                  onChange={(e) => setNewResearch({ ...newResearch, title: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-red-500"
                />
                <input
                  type="text"
                  placeholder="Category (e.g., Political, Social)"
                  value={newResearch.category}
                  onChange={(e) => setNewResearch({ ...newResearch, category: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-red-500"
                />
                <RichTextEditor
                  value={newResearch.content}
                  onChange={(value) => setNewResearch({ ...newResearch, content: value })}
                  placeholder="Write your research content..."
                  darkMode={true}
                />
                <FileUploader
                  accept=".pdf,.doc,.docx,.txt"
                  label="Attach Document"
                  darkMode={true}
                  onFileSelect={(file) => setNewResearch({ ...newResearch, file: { name: file.name, url: file.url } })}
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAddResearch}
                  className="w-full py-4 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-500"
                >
                  Add Research
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
