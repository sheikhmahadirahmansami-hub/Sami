import { motion } from 'framer-motion';
import { FiMail, FiPhone, FiCalendar, FiDroplet, FiHome, FiCamera } from 'react-icons/fi';
import { useAuthStore } from '../store/authStore';
import { useContentStore } from '../store/contentStore';
import FileUploader from '../components/FileUploader';

interface HeroSectionProps {
  darkMode: boolean;
}

export default function HeroSection({ darkMode }: HeroSectionProps) {
  const { isAuthenticated } = useAuthStore();
  const { profileImage, updateProfileImage } = useContentStore();

  const personalInfo = [
    { icon: FiCalendar, label: 'Date of Birth', value: '25.06.2009' },
    { icon: FiHome, label: 'Institution', value: 'Dhaka College' },
    { icon: FiDroplet, label: 'Blood Group', value: 'O+' },
    { icon: FiMail, label: 'E-mail', value: 'sheikhmahadirahmansami@gmail.com', isLink: true },
    { icon: FiPhone, label: 'Mobile', value: '01410430830', isLink: true },
  ];

  return (
    <section
      id="hero"
      className={`min-h-screen relative overflow-hidden ${
        darkMode
          ? 'bg-gradient-to-br from-gray-900 via-black to-gray-900'
          : 'bg-gradient-to-br from-slate-50 via-white to-indigo-50'
      }`}
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          className={`absolute -top-1/2 -left-1/2 w-full h-full rounded-full blur-3xl ${
            darkMode ? 'bg-red-900/20' : 'bg-indigo-200/50'
          }`}
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          className={`absolute -bottom-1/2 -right-1/2 w-full h-full rounded-full blur-3xl ${
            darkMode ? 'bg-purple-900/20' : 'bg-purple-200/50'
          }`}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center min-h-[calc(100vh-200px)]">
          {/* Left Side - Profile Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center lg:justify-end order-2 lg:order-1"
          >
            <div className="relative">
              {/* Glow Effect */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                className={`absolute inset-0 rounded-full blur-2xl ${
                  darkMode ? 'bg-gradient-to-r from-red-600/30 to-purple-600/30' : 'bg-gradient-to-r from-indigo-400/30 to-purple-400/30'
                }`}
              />
              
              {/* Image Container */}
              <div className={`relative w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 rounded-full overflow-hidden border-4 ${
                darkMode ? 'border-gray-800' : 'border-white'
              } shadow-2xl`}>
                {profileImage ? (
                  <img
                    src={profileImage}
                    alt="Sheikh Mahadi Rahman Sami"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className={`w-full h-full flex items-center justify-center ${
                    darkMode ? 'bg-gray-800' : 'bg-gray-200'
                  }`}>
                    <FiCamera size={48} className={darkMode ? 'text-gray-600' : 'text-gray-400'} />
                  </div>
                )}
              </div>

              {/* Admin Upload */}
              {isAuthenticated && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-64"
                >
                  <FileUploader
                    accept="image/*"
                    label=""
                    darkMode={darkMode}
                    onFileSelect={(file) => updateProfileImage(file.url)}
                  />
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* Right Side - Info */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-center lg:text-left order-1 lg:order-2"
          >
            {/* Animated Name */}
            <motion.div className="mb-8">
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className={`text-sm sm:text-base uppercase tracking-[0.3em] mb-4 ${
                  darkMode ? 'text-gray-400' : 'text-gray-500'
                }`}
              >
                Welcome to my world
              </motion.p>
              
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, type: 'spring' }}
                className={`text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold font-['Playfair_Display'] leading-tight ${
                  darkMode ? 'text-white' : 'text-gray-900'
                }`}
              >
                <span className="block">Sheikh Mahadi</span>
                <motion.span
                  initial={{ backgroundPosition: '0% 50%' }}
                  animate={{ backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'] }}
                  transition={{ duration: 5, repeat: Infinity, ease: 'linear' }}
                  className={`block bg-clip-text text-transparent bg-gradient-to-r ${
                    darkMode
                      ? 'from-red-400 via-purple-400 to-red-400'
                      : 'from-indigo-600 via-purple-600 to-indigo-600'
                  } bg-[length:200%_auto]`}
                >
                  Rahman Sami
                </motion.span>
              </motion.h1>
            </motion.div>

            {/* Personal Info Cards */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="space-y-4 mb-8"
            >
              {personalInfo.map((info, index) => (
                <motion.div
                  key={info.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  whileHover={{ x: 10 }}
                  className={`flex items-center space-x-4 p-3 rounded-xl transition-all ${
                    darkMode
                      ? 'bg-gray-800/50 hover:bg-gray-800'
                      : 'bg-white/80 hover:bg-white shadow-sm hover:shadow-md'
                  }`}
                >
                  <div className={`p-2 rounded-lg ${
                    darkMode ? 'bg-red-900/30 text-red-400' : 'bg-indigo-100 text-indigo-600'
                  }`}>
                    <info.icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs uppercase tracking-wider ${
                      darkMode ? 'text-gray-500' : 'text-gray-400'
                    }`}>
                      {info.label}
                    </p>
                    {info.isLink ? (
                      <a
                        href={info.label === 'E-mail' ? `mailto:${info.value}` : `tel:${info.value}`}
                        className={`text-sm font-medium truncate block hover:underline ${
                          darkMode ? 'text-white' : 'text-gray-900'
                        }`}
                      >
                        {info.value}
                      </a>
                    ) : (
                      <p className={`text-sm font-medium ${
                        darkMode ? 'text-white' : 'text-gray-900'
                      }`}>
                        {info.value}
                      </p>
                    )}
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {/* Contact Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
            >
              <motion.a
                href="mailto:sheikhmahadirahmansami@gmail.com"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`inline-flex items-center space-x-2 px-8 py-4 rounded-full font-semibold transition-all ${
                  darkMode
                    ? 'bg-gradient-to-r from-red-600 to-red-700 text-white hover:from-red-500 hover:to-red-600 shadow-lg shadow-red-900/30'
                    : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-500 hover:to-purple-500 shadow-lg shadow-indigo-200'
                }`}
              >
                <FiMail size={20} />
                <span>Get In Touch</span>
              </motion.a>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className={`w-6 h-10 rounded-full border-2 flex justify-center pt-2 ${
            darkMode ? 'border-gray-600' : 'border-gray-400'
          }`}
        >
          <motion.div
            animate={{ height: [4, 12, 4] }}
            transition={{ duration: 2, repeat: Infinity }}
            className={`w-1 rounded-full ${
              darkMode ? 'bg-gray-400' : 'bg-gray-600'
            }`}
          />
        </motion.div>
      </motion.div>
    </section>
  );
}
