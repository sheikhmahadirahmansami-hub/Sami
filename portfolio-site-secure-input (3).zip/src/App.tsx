import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import HeroSection from './sections/HeroSection';
import RebelSection from './sections/RebelSection';
import WriterSection from './sections/WriterSection';
import EditorSection from './sections/EditorSection';
import { useAuthStore } from './store/authStore';

export function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [activeSection, setActiveSection] = useState('hero');
  const [isLoading, setIsLoading] = useState(true);
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Intersection Observer for active section detection
    const sections = ['hero', 'rebel', 'writer', 'editor'];
    const observers: IntersectionObserver[] = [];

    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        const observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                setActiveSection(sectionId);
              }
            });
          },
          { threshold: 0.3 }
        );
        observer.observe(element);
        observers.push(observer);
      }
    });

    return () => {
      observers.forEach((observer) => observer.disconnect());
    };
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <>
      {/* Loading Screen */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="fixed inset-0 z-[200] flex items-center justify-center bg-black"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="text-center"
            >
              <motion.h1
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-4xl md:text-6xl font-bold text-white font-['Playfair_Display'] mb-4"
              >
                SMRS
              </motion.h1>
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="w-32 h-1 bg-gradient-to-r from-red-600 via-purple-600 to-indigo-600 mx-auto rounded-full"
              />
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="text-gray-500 mt-4 text-sm"
              >
                Loading experience...
              </motion.p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Admin Mode Indicator */}
      <AnimatePresence>
        {isAuthenticated && (
          <motion.div
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-40 px-4 py-2 bg-green-600 text-white text-sm font-semibold rounded-full shadow-lg flex items-center space-x-2"
          >
            <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
            <span>Admin Edit Mode Active</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className={`min-h-screen ${darkMode ? 'bg-black' : 'bg-white'}`}>
        {/* Navigation */}
        <Navigation
          darkMode={darkMode}
          toggleDarkMode={toggleDarkMode}
          activeSection={activeSection}
          setActiveSection={setActiveSection}
        />

        {/* Main Content */}
        <main>
          <HeroSection darkMode={darkMode} />
          <RebelSection />
          <WriterSection />
          <EditorSection />
        </main>

        {/* Footer */}
        <Footer darkMode={darkMode} />
      </div>

      {/* Global Styles */}
      <style>{`
        html {
          scroll-behavior: smooth;
        }
        
        body {
          font-family: 'Inter', sans-serif;
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
        }
        
        ::-webkit-scrollbar-track {
          background: ${darkMode ? '#000' : '#f1f1f1'};
        }
        
        ::-webkit-scrollbar-thumb {
          background: ${darkMode ? '#333' : '#888'};
          border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: ${darkMode ? '#555' : '#555'};
        }

        /* Selection */
        ::selection {
          background: ${darkMode ? 'rgba(220, 38, 38, 0.3)' : 'rgba(99, 102, 241, 0.3)'};
          color: ${darkMode ? '#fff' : '#000'};
        }

        /* Line clamp */
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .line-clamp-4 {
          display: -webkit-box;
          -webkit-line-clamp: 4;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        /* Prose overrides */
        .prose img {
          border-radius: 0.5rem;
        }

        .prose a {
          color: ${darkMode ? '#f87171' : '#6366f1'};
        }
      `}</style>
    </>
  );
}
