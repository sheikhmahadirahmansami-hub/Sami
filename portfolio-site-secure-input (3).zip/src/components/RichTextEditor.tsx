import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { FiBold, FiItalic, FiUnderline, FiList, FiAlignLeft, FiAlignCenter, FiAlignRight, FiImage, FiLink } from 'react-icons/fi';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  darkMode?: boolean;
}

export default function RichTextEditor({ value, onChange, placeholder, darkMode = true }: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isFocused, setIsFocused] = useState(false);

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const toolbarButtons = [
    { icon: FiBold, command: 'bold', label: 'Bold' },
    { icon: FiItalic, command: 'italic', label: 'Italic' },
    { icon: FiUnderline, command: 'underline', label: 'Underline' },
    { icon: FiList, command: 'insertUnorderedList', label: 'List' },
    { icon: FiAlignLeft, command: 'justifyLeft', label: 'Align Left' },
    { icon: FiAlignCenter, command: 'justifyCenter', label: 'Center' },
    { icon: FiAlignRight, command: 'justifyRight', label: 'Align Right' },
  ];

  const handleAddLink = () => {
    const url = prompt('Enter URL:');
    if (url) {
      execCommand('createLink', url);
    }
  };

  const handleAddImage = () => {
    const url = prompt('Enter image URL:');
    if (url) {
      execCommand('insertImage', url);
    }
  };

  return (
    <div className={`rounded-xl overflow-hidden border ${
      isFocused 
        ? darkMode ? 'border-red-500 ring-2 ring-red-500/20' : 'border-indigo-500 ring-2 ring-indigo-500/20'
        : darkMode ? 'border-gray-700' : 'border-gray-300'
    } transition-all`}>
      {/* Toolbar */}
      <div className={`flex flex-wrap gap-1 p-2 border-b ${
        darkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-100 border-gray-200'
      }`}>
        {toolbarButtons.map((button) => (
          <motion.button
            key={button.command}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            type="button"
            onClick={() => execCommand(button.command)}
            className={`p-2 rounded-lg transition-colors ${
              darkMode 
                ? 'text-gray-400 hover:text-white hover:bg-gray-700'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200'
            }`}
            title={button.label}
          >
            <button.icon size={16} />
          </motion.button>
        ))}
        <div className={`w-px ${darkMode ? 'bg-gray-700' : 'bg-gray-300'} mx-1`} />
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          type="button"
          onClick={handleAddLink}
          className={`p-2 rounded-lg transition-colors ${
            darkMode 
              ? 'text-gray-400 hover:text-white hover:bg-gray-700'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200'
          }`}
          title="Add Link"
        >
          <FiLink size={16} />
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          type="button"
          onClick={handleAddImage}
          className={`p-2 rounded-lg transition-colors ${
            darkMode 
              ? 'text-gray-400 hover:text-white hover:bg-gray-700'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200'
          }`}
          title="Add Image"
        >
          <FiImage size={16} />
        </motion.button>
      </div>

      {/* Editor */}
      <div
        ref={editorRef}
        contentEditable
        onInput={handleInput}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        dangerouslySetInnerHTML={{ __html: value }}
        className={`min-h-[200px] p-4 focus:outline-none ${
          darkMode ? 'bg-gray-900/50 text-white' : 'bg-white text-gray-900'
        }`}
        data-placeholder={placeholder}
        style={{
          wordBreak: 'break-word',
        }}
      />
      
      <style>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: ${darkMode ? '#6b7280' : '#9ca3af'};
          pointer-events: none;
        }
      `}</style>
    </div>
  );
}
