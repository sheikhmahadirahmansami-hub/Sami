import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiUpload, FiFile, FiImage, FiX, FiCheck } from 'react-icons/fi';

interface FileUploaderProps {
  onFileSelect: (file: { name: string; url: string; type: string }) => void;
  accept?: string;
  label?: string;
  darkMode?: boolean;
}

export default function FileUploader({ onFileSelect, accept = '*', label = 'Upload File', darkMode = true }: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; url: string } | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    setIsUploading(true);
    
    // Convert file to base64 for local storage (in production, use proper file upload)
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setTimeout(() => {
        setUploadedFile({ name: file.name, url: result });
        onFileSelect({ name: file.name, url: result, type: file.type });
        setIsUploading(false);
      }, 500);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleClick = () => {
    inputRef.current?.click();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const clearFile = () => {
    setUploadedFile(null);
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="space-y-2">
      <label className={`block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
        {label}
      </label>
      
      <motion.div
        whileHover={{ scale: 1.01 }}
        onClick={handleClick}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`relative border-2 border-dashed rounded-xl p-6 cursor-pointer transition-all ${
          isDragging
            ? darkMode ? 'border-red-500 bg-red-500/10' : 'border-indigo-500 bg-indigo-50'
            : darkMode ? 'border-gray-700 hover:border-gray-600 bg-gray-800/30' : 'border-gray-300 hover:border-gray-400 bg-gray-50'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          onChange={handleInputChange}
          className="hidden"
        />

        <AnimatePresence mode="wait">
          {isUploading ? (
            <motion.div
              key="uploading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-4"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className={`w-10 h-10 border-3 rounded-full ${
                  darkMode ? 'border-red-500 border-t-transparent' : 'border-indigo-500 border-t-transparent'
                }`}
              />
              <p className={`mt-3 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Uploading...
              </p>
            </motion.div>
          ) : uploadedFile ? (
            <motion.div
              key="uploaded"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-between"
            >
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${darkMode ? 'bg-green-900/50' : 'bg-green-100'}`}>
                  {uploadedFile.url.startsWith('data:image') ? (
                    <FiImage size={20} className={darkMode ? 'text-green-400' : 'text-green-600'} />
                  ) : (
                    <FiFile size={20} className={darkMode ? 'text-green-400' : 'text-green-600'} />
                  )}
                </div>
                <div>
                  <p className={`text-sm font-medium truncate max-w-[200px] ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {uploadedFile.name}
                  </p>
                  <p className={`text-xs flex items-center ${darkMode ? 'text-green-400' : 'text-green-600'}`}>
                    <FiCheck size={12} className="mr-1" /> Uploaded
                  </p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  clearFile();
                }}
                className={`p-2 rounded-lg ${
                  darkMode ? 'bg-gray-700 hover:bg-gray-600 text-gray-300' : 'bg-gray-200 hover:bg-gray-300 text-gray-600'
                }`}
              >
                <FiX size={16} />
              </motion.button>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-4"
            >
              <FiUpload size={32} className={darkMode ? 'text-gray-500' : 'text-gray-400'} />
              <p className={`mt-3 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Drag & drop or click to upload
              </p>
              <p className={`text-xs mt-1 ${darkMode ? 'text-gray-600' : 'text-gray-400'}`}>
                {accept === '*' ? 'All file types supported' : accept}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
