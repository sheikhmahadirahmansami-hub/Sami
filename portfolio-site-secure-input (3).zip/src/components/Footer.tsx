import { motion } from 'framer-motion';
import { FiHeart, FiMail, FiPhone, FiArrowUp } from 'react-icons/fi';

interface FooterProps {
  darkMode: boolean;
}

export default function Footer({ darkMode }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className={`relative ${darkMode ? 'bg-black' : 'bg-gray-900'}`}>
      {/* Gradient Border */}
      <div className={`absolute top-0 left-0 right-0 h-px ${
        darkMode 
          ? 'bg-gradient-to-r from-transparent via-red-600 to-transparent'
          : 'bg-gradient-to-r from-transparent via-indigo-600 to-transparent'
      }`} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div className="text-center md:text-left">
            <motion.h3
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-2xl font-bold text-white font-['Playfair_Display'] mb-4"
            >
              Sheikh Mahadi Rahman Sami
            </motion.h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              A multi-dimensional creative soul — rebel thinker, poetic writer, and visual artist.
            </p>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <div className="space-y-2">
              {['Home', 'The Rebel', 'পাণ্ডুলিপি', 'Photo Editor'].map((link, index) => (
                <motion.a
                  key={link}
                  href={`#${['hero', 'rebel', 'writer', 'editor'][index]}`}
                  whileHover={{ x: 5 }}
                  className="block text-gray-400 hover:text-white transition-colors"
                >
                  {link}
                </motion.a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div className="text-center md:text-right">
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <div className="space-y-3">
              <a
                href="mailto:sheikhmahadirahmansami@gmail.com"
                className="flex items-center justify-center md:justify-end space-x-2 text-gray-400 hover:text-white transition-colors"
              >
                <FiMail size={16} />
                <span className="text-sm">sheikhmahadirahmansami@gmail.com</span>
              </a>
              <a
                href="tel:01410430830"
                className="flex items-center justify-center md:justify-end space-x-2 text-gray-400 hover:text-white transition-colors"
              >
                <FiPhone size={16} />
                <span className="text-sm">01410430830</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm flex items-center space-x-1">
              <span>© {new Date().getFullYear()} Sheikh Mahadi Rahman Sami. Made with</span>
              <FiHeart className="text-red-500" size={14} />
            </p>

            {/* Back to Top */}
            <motion.button
              whileHover={{ scale: 1.1, y: -3 }}
              whileTap={{ scale: 0.9 }}
              onClick={scrollToTop}
              className={`p-3 rounded-full ${
                darkMode 
                  ? 'bg-gray-800 text-white hover:bg-red-900'
                  : 'bg-gray-800 text-white hover:bg-indigo-700'
              } transition-colors`}
            >
              <FiArrowUp size={20} />
            </motion.button>
          </div>
        </div>
      </div>
    </footer>
  );
}
