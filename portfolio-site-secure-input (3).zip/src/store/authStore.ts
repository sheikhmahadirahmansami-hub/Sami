import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Password hash (hashed version of $@M!2213590786)
const PASSWORD_HASH = '5a4d2132323133353930373836';

interface AuthState {
  isAuthenticated: boolean;
  login: (password: string) => boolean;
  logout: () => void;
}

const hashPassword = (password: string): string => {
  // Simple encoding - in production use proper hashing
  return Array.from(password).map(c => c.charCodeAt(0).toString(16)).join('');
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      login: (password: string) => {
        const hashedInput = hashPassword(password);
        if (hashedInput === PASSWORD_HASH) {
          set({ isAuthenticated: true });
          return true;
        }
        return false;
      },
      logout: () => set({ isAuthenticated: false }),
    }),
    {
      name: 'auth-storage',
    }
  )
);
