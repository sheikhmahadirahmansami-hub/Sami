import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ContentItem {
  id: string;
  title: string;
  content: string;
  category?: string;
  fileUrl?: string;
  fileName?: string;
  createdAt: string;
}

interface ContentState {
  // Hero Section
  profileImage: string;
  
  // Rebel Section
  rebelTitle: string;
  rebelVision: string;
  rebelResearch: ContentItem[];
  rebelImage: string;
  
  // Writer Section
  writerTitle: string;
  writings: ContentItem[];
  writerImage: string;
  
  // Photo Editor Section
  editorTitle: string;
  projects: ContentItem[];
  editorImage: string;
  
  // User submissions
  questions: ContentItem[];
  emotions: ContentItem[];
  
  // Actions
  updateProfileImage: (url: string) => void;
  updateRebelTitle: (title: string) => void;
  updateRebelVision: (vision: string) => void;
  addResearch: (item: ContentItem) => void;
  updateResearch: (id: string, item: Partial<ContentItem>) => void;
  deleteResearch: (id: string) => void;
  updateRebelImage: (url: string) => void;
  
  updateWriterTitle: (title: string) => void;
  addWriting: (item: ContentItem) => void;
  updateWriting: (id: string, item: Partial<ContentItem>) => void;
  deleteWriting: (id: string) => void;
  updateWriterImage: (url: string) => void;
  
  updateEditorTitle: (title: string) => void;
  addProject: (item: ContentItem) => void;
  updateProject: (id: string, item: Partial<ContentItem>) => void;
  deleteProject: (id: string) => void;
  updateEditorImage: (url: string) => void;
  
  addQuestion: (item: ContentItem) => void;
  addEmotion: (item: ContentItem) => void;
}

export const useContentStore = create<ContentState>()(
  persist(
    (set) => ({
      profileImage: '',
      rebelTitle: 'Raise Your Voice, Raise The Movement',
      rebelVision: 'In a world that demands conformity, we choose to question. Every revolution begins with a single thought that refuses to be silenced. Our vision is to create a platform where ideas flourish, where the status quo is challenged, and where every voice matters. We believe in the power of collective consciousness to reshape societies and redefine what is possible.',
      rebelResearch: [],
      rebelImage: '',
      
      writerTitle: 'পাণ্ডুলিপি',
      writings: [
        {
          id: '1',
          title: 'রাতের কবিতা',
          content: 'চাঁদের আলোয় ভিজে যায় মন,\nতারার মেলায় হারিয়ে যাই।\nএকলা রাতে কবিতা লিখি,\nস্বপ্নের দেশে পাড়ি জমাই।',
          category: 'Poetry',
          createdAt: new Date().toISOString()
        }
      ],
      writerImage: '',
      
      editorTitle: 'Visual Artistry',
      projects: [],
      editorImage: '',
      
      questions: [],
      emotions: [],
      
      updateProfileImage: (url) => set({ profileImage: url }),
      updateRebelTitle: (title) => set({ rebelTitle: title }),
      updateRebelVision: (vision) => set({ rebelVision: vision }),
      addResearch: (item) => set((state) => ({ rebelResearch: [...state.rebelResearch, item] })),
      updateResearch: (id, item) => set((state) => ({
        rebelResearch: state.rebelResearch.map(r => r.id === id ? { ...r, ...item } : r)
      })),
      deleteResearch: (id) => set((state) => ({
        rebelResearch: state.rebelResearch.filter(r => r.id !== id)
      })),
      updateRebelImage: (url) => set({ rebelImage: url }),
      
      updateWriterTitle: (title) => set({ writerTitle: title }),
      addWriting: (item) => set((state) => ({ writings: [...state.writings, item] })),
      updateWriting: (id, item) => set((state) => ({
        writings: state.writings.map(w => w.id === id ? { ...w, ...item } : w)
      })),
      deleteWriting: (id) => set((state) => ({
        writings: state.writings.filter(w => w.id !== id)
      })),
      updateWriterImage: (url) => set({ writerImage: url }),
      
      updateEditorTitle: (title) => set({ editorTitle: title }),
      addProject: (item) => set((state) => ({ projects: [...state.projects, item] })),
      updateProject: (id, item) => set((state) => ({
        projects: state.projects.map(p => p.id === id ? { ...p, ...item } : p)
      })),
      deleteProject: (id) => set((state) => ({
        projects: state.projects.filter(p => p.id !== id)
      })),
      updateEditorImage: (url) => set({ editorImage: url }),
      
      addQuestion: (item) => set((state) => ({ questions: [...state.questions, item] })),
      addEmotion: (item) => set((state) => ({ emotions: [...state.emotions, item] })),
    }),
    {
      name: 'content-storage',
    }
  )
);
